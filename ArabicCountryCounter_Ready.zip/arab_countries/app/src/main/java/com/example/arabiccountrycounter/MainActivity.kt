package com.example.arabiccountrycounter

import android.app.*
import android.os.Bundle
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import java.util.Locale

data class Country(val name: String, val flag: String)

class MainActivity : Activity() {
    private val countries = listOf(
        Country("السعودية","🇸🇦"), Country("الإمارات","🇦🇪"), Country("قطر","🇶🇦"),
        Country("الكويت","🇰🇼"), Country("البحرين","🇧🇭"), Country("عُمان","🇴🇲"),
        Country("اليمن","🇾🇪"), Country("العراق","🇮🇶"), Country("الأردن","🇯🇴"),
        Country("فلسطين","🇵🇸"), Country("لبنان","🇱🇧"), Country("سوريا","🇸🇾"),
        Country("مصر","🇪🇬"), Country("ليبيا","🇱🇾"), Country("تونس","🇹🇳"),
        Country("الجزائر","🇩🇿"), Country("المغرب","🇲🇦"), Country("موريتانيا","🇲🇷"),
        Country("السودان","🇸🇩"), Country("الصومال","🇸🇴"), Country("جيبوتي","🇩🇯"),
        Country("جزر القمر","🇰🇲")
    )
    private val counts = IntArray(countries.size)
    private lateinit var totalView: TextView
    private lateinit var container: LinearLayout
    private val prefs by lazy { getSharedPreferences("counter", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        countries.indices.forEach { counts[it] = prefs.getInt("c$it", 0) }
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 28)
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_RTL
        }

        val title = TextView(this).apply {
            text = "🎁 مفاجأتك لأخوكم علاء من غزة ❤️"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(25,25,25))
            setPadding(4, 8, 4, 18)
        }
        container.addView(title, LinearLayout.LayoutParams(-1, -2))

        val appTitle = TextView(this).apply {
            text = "🌍 عداد الدول العربية"
            textSize = 28f
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(4, 4, 4, 14)
        }
        container.addView(appTitle)

        totalView = TextView(this).apply {
            textSize = 21f
            gravity = Gravity.CENTER
            setPadding(8, 14, 8, 18)
        }
        container.addView(totalView)

        // إضافة الدول مرتبة من الأعلى إلى الأقل
        addSortedCountryRows()

        val manual = Button(this).apply {
            text = "✏️ إدخال عدد يدوي"
            textSize = 17f
            setOnClickListener { manualDialog() }
        }
        container.addView(manual, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 20, 0, 8) })

        val reset = Button(this).apply {
            text = "🔄 تصفير جميع الأعداد"
            textSize = 17f
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("تأكيد التصفير")
                    .setMessage("هل تريد تصفير جميع الدول؟")
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("تصفير") { _, _ ->
                        java.util.Arrays.fill(counts, 0)
                        saveAll()
                        refresh()
                        rebuildRows()
                    }.show()
            }
        }
        container.addView(reset)

        scroll.addView(container)
        setContentView(scroll)
        refresh()
    }

    /** يرتب الدول حسب العدد من الأعلى إلى الأقل */
    private fun getSortedIndices(): List<Int> {
        return countries.indices.sortedByDescending { counts[it] }
    }

    private fun addSortedCountryRows() {
        getSortedIndices().forEach { addCountryRow(it) }
    }

    private fun addCountryRow(i: Int) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(10, 8, 10, 8)
            layoutDirection = LinearLayout.LAYOUT_DIRECTION_LTR
        }
        val name = TextView(this).apply {
            text = "${countries[i].flag}  ${countries[i].name}"
            textSize = 19f
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(name, LinearLayout.LayoutParams(0, 60, 1f))
        val count = TextView(this).apply {
            text = counts[i].toString()
            textSize = 20f
            gravity = Gravity.CENTER
            setMinWidth(70)
        }
        row.addView(count, LinearLayout.LayoutParams(80, 60))
        val plus = Button(this).apply {
            text = "+"
            textSize = 24f
            setOnClickListener {
                counts[i]++
                prefs.edit().putInt("c$i", counts[i]).apply()
                refresh()
                rebuildRows()   // يعيد الترتيب فوراً بعد الزيادة
            }
        }
        row.addView(plus, LinearLayout.LayoutParams(65, 60))
        container.addView(row)
    }

    private fun rebuildRows() {
        val headerCount = 3   // العنوان + اسم التطبيق + الإجمالي
        while (container.childCount > headerCount) {
            container.removeViewAt(headerCount)
        }
        // إضافة الدول مرتبة من الأعلى إلى الأقل
        addSortedCountryRows()

        val manual = Button(this).apply {
            text = "✏️ إدخال عدد يدوي"
            textSize = 17f
            setOnClickListener { manualDialog() }
        }
        container.addView(manual, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 20, 0, 8) })

        val reset = Button(this).apply {
            text = "🔄 تصفير جميع الأعداد"
            textSize = 17f
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("تأكيد التصفير")
                    .setMessage("هل تريد تصفير جميع الدول؟")
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("تصفير") { _, _ ->
                        java.util.Arrays.fill(counts, 0)
                        saveAll()
                        refresh()
                        rebuildRows()
                    }.show()
            }
        }
        container.addView(reset)
    }

    private fun manualDialog() {
        val names = countries.map { "${it.flag} ${it.name}" }.toTypedArray()
        var selected = 0
        val input = EditText(this).apply {
            hint = "اكتب العدد"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textSize = 20f
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 10, 30, 0)
        }
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle("إدخال عدد يدوي")
            .setSingleChoiceItems(names, 0) { _, which -> selected = which }
            .setView(box)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ") { _, _ ->
                val n = input.text.toString().toIntOrNull()
                if (n != null) {
                    counts[selected] = n
                    saveAll()
                    refresh()
                    rebuildRows()   // يعيد الترتيب بعد التعديل اليدوي
                }
            }.show()
    }

    private fun saveAll() {
        val e = prefs.edit()
        countries.indices.forEach { e.putInt("c$it", counts[it]) }
        e.apply()
    }

    private fun refresh() {
        totalView.text = "الإجمالي: ${counts.sum()}"
    }
}
